import React, { useState, useEffect } from 'react';

const FindFreelancer = () => {
   useEffect(()=>{
    window.scrollTo(0, 0);
   },[])
    return (
       <>
       <h1>Freelancer's Will Show Here</h1>
       </>
    );
};

export default FindFreelancer;
